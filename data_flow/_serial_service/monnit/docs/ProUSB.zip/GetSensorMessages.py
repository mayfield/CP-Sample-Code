#!/usr/bin/python

import serial
import time
import datetime
from CommandGenerator import CommandGenerator as cmdGen
from GatewayMessage import GatewayMessage as GW
from MonnitTcp import TcpClient as TcpClient

messageList = {}

def processResponse(response):	
	pass
	#print ", ".join([hex(ord(char)) for char in response])

def getTime():
	MonnitEpoch = time.mktime(datetime.datetime(2010, 1, 1, 0, 0).timetuple())
	now = int(time.time()-MonnitEpoch)
	timearray = [now & 0xFF000000, now & 0x00FF0000, now & 0x0000FF00, now & 0x000000FF]
	return timearray


def sendMessage(message):
	if type(message) is not bytearray:
		message = bytearray(message)
	ser.write(message)
	data = ""
	while True:
		previous = data
		data+=ser.read()
		if previous == data:
			break
	processResponse(data)
	return data


ser = serial.Serial(
		port='/dev/ttyUSB0',
		baudrate=115200,
		parity=serial.PARITY_NONE,
		timeout=.1
	)

activeMessage = bytearray.fromhex("c5 07 00 21 01 39 b5 31 0b 1e")
idleMessage = bytearray.fromhex("c5 07 00 21 00 a8 b4 31 0b f8")

sendMessage(activeMessage)

i=0
while True:
	queuedMessageRequest = cmdGen.getQueuedMessageRequest([0x85,0x03,0x00,0x00], i, 0x00)
	print [hex(num) for num in queuedMessageRequest]
	data = sendMessage(queuedMessageRequest)
	print "Response from gateway: \n\t%s" % ", ".join([hex(ord(d)) for d in data])
	try:	
		dataResponseCmd = ord(data[3])
		dataResponseCode = ord(data[8])
		if dataResponseCmd == 0x24 and dataResponseCode == 0xc:
			break
		else:
			messageList["".join([str(t) for t in getTime()])] = data
	except:
		pass #probably out of range on data array
	i+=1
	i=i%256

messagePacket = GW(messageList)
response = TcpClient.SendData(messagePacket.getMessage())
readableresponse = [hex(ord(item)) for item in response]

print "Response from Server: \n\t%s" % readableresponse

print 'serial closed'
ser.close()
